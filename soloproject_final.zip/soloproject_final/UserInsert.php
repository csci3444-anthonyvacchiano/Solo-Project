<?php session_start(); ?>
<!DOCTYPE html>
<html>
<head>
  <title>User Info</title>
  <a href = "HubPage.php">Return to HubPage</a>
</head>

<body>
  <div class="maindiv">
    <!--HTML Form -->
     <div class="form_div">
        <div class="title">
          <h2>Insert User Info</h2>
        </div>

      <form action="UserInsert.php" method="post">
      <h2>User Information:</h2>

      <?php
        $Name = $UserID = $Permissions = $UserType = "";
      ?>

      <label>Name:</label>
        <input class="input" name="Name" type="text" value="">
        <br><br>

      <label>UserID:</label>
        <input class="input" name="UserID" type="text" value="">
        <br><br>

      <label>Permissions:</label>
        <input class="input" name="Permissions" type="text" value="">
        <br><br>

      <label>User Type:</label>
        <input class="input" name="UserType" type="text" value="">
        <br><br>

    <input class="submit" name="submit" type="submit" value="Submit">
    </form>
    </div>
    </div>

  <?php
    $connection = mysqli_connect("localhost", "root", "", "soloprojtest"); // Establishing Connection with Server
    $db = mysqli_select_db($connection, "soloprojtest"); // Selecting Database from Server
    if(isset($_POST['submit']))
      { // Fetching variables of the form which travels in URL
        $Name = $_POST['Name'];
        $UserID = $_POST['UserID']; 
        $Permissions = $_POST['Permissions'];
        $UserTypr = $_POST['UserType'];          
      }

    //Insert Query of SQL
    $query = mysqli_query($connection, "INSERT INTO User (Name, UserID, Permissions, UserType) VALUES ('$Name' , '$UserID', '$Permissions', '$UserType')");

    mysqli_close($connection); // Closing Connection with Server
  ?>

</body>
</html>