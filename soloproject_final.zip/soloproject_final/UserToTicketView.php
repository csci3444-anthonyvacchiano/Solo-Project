<?php session_start(); ?>
<!DOCTYPE html>
<html>
<head>
<style tyle="text/css">
h1 {
	text-align: center;
	}
h2 {
	text-align: center;
}
table {
	text-align: center;
	vertical-align: middle;
	border: 2px solid black;
	border-collapse: collapse;
	margin: 20px auto;
	font-family: Verdana, Helvetica, serif;
	}
table tr:nth-child(even) {
	background-color: #ccc;
	}
table tr:first-child {
	border-bottom: 2px solid black;
	font-weight: bold;
	}
td {
	padding: 5px 15px 5px 15px;
	border: 1px solid black;
	}
p {
	text-align:center;
}
a:visited {
	color:blue;
}
</style>
</head>
<body>
<a href = "HubPage.php">Return to HubPage</a>
<h2> Users' Tickets </h2>
<table>
	<tr>
		<td><a href = "UsersToTicketView.php?sort=TicketID">TicketID</td>
		<td><a href = "UsersToTicketView.php?sort=UserID">UserID</td>
	</tr>	
<?php

 if (!empty($_GET))
 { 
 	$sort = $_GET['sort'];
 }
 $sql = "SELECT * FROM UserToTicket";
 $switchTest = false;
 if (!empty($_GET))
 {
 	if ($sort == "TicketID")
 	{
		$sql .= " ORDER BY TicketID DESC";
	}
 	else if ($sort == "UserID")
 	{
		$sql .= " ORDER BY UserID DESC";
	}
 }


 $dbConnect = mysqli_connect("localhost", "root","","soloprojtest") or die(mysql_error()); 
 $data = mysqli_query($dbConnect, $sql) or die("Unable to select data"); 
 #$info = mysqli_fetch_array($data);

 while($info = mysqli_fetch_array( $data )) 
 { 
 echo "<tr>"; 
 echo "<td>".$info['TicketID']. " </td>";
 echo "<td>".$info['UserID'] . "</td> "; 
 echo "</tr>";
 } 
mysqli_close($dbConnect);
?> 

</table>
</body>
</html>