<?php session_start(); ?>
<!DOCTYPE html>
<html>
<head>
  <title>Events Info</title>
  <a href = "HubPage.php">Return to HubPage</a>
</head>

<body>
  <div class="maindiv">
    <!--HTML Form -->
     <div class="form_div">
        <div class="title">
          <h2>Insert Location Info</h2>
        </div>

      <form action="LocationInsert.php" method="post">
      <h2>Event Information:</h2>

      <?php
         $DepartureLocation = $ArrivalLocation = $DeparturePort = $ArrivalPort = $LocationID ="";
      ?>

      <label>DepartureLocation:</label>
        <input class="input" name="DepartureLocation" type="text" value="">
        <br><br>

      <label>ArrivalLocation:</label>
        <input class="input" name="ArrivalLocation" type="text" value="">
        <br><br>

      <label>DeparturePort:</label>
        <input class="input" name="DeparturePort" type="text" value="">
        <br><br>

      <label>ArrivalPort:</label>
        <input class="input" name="ArrivalPort" type="text" value="">
        <br><br>

      <label>LocationID:</label>
        <input class="input" name="LocationID" type="text" value="">
        <br><br>

    <input class="submit" name="submit" type="submit" value="Submit">
    </form>
    </div>
    </div>

  <?php
    $connection = mysqli_connect("localhost", "root", "", "soloprojtest"); // Establishing Connection with Server
    $db = mysqli_select_db($connection, "soloprojtest"); // Selecting Database from Server
    if(isset($_POST['submit']))
      { // Fetching variables of the form which travels in URL
        $DepartureLocation= $_POST['DepartureLocation'];
        $ArrivalLocation = $_POST['ArrivalLocation'];
        $DeparturePort = $_POST['DeparturePort'];
        $ArrivalPort = $_POST['ArrivalPort'];  
        $LocationID = $_POST['LocationID'];       
      }

    //Insert Query of SQL
    $query = mysqli_query($connection, "INSERT INTO Location (DepartureLocation, ArrivalLocation, DeparturePort, ArrivalPort,LocationID) VALUES ('$DepartureLocation', '$ArrivalLocation', '$DeparturePort', '$ArrivalPort', '$LocationID')");

    mysqli_close($connection); // Closing Connection with Server
  ?>

</body>
</html>