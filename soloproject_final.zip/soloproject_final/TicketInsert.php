<?php session_start(); ?>
<!DOCTYPE html>
<html>
<head>
  <title>Events Info</title>
  <a href = "HubPage.php">Return to HubPage</a>
</head>

<body>
  <div class="maindiv">
    <!--HTML Form -->
     <div class="form_div">
        <div class="title">
          <h2>Insert Ride Infor</h2>
        </div>

      <form action="TicketInsert.php" method="post">
      <h2>Event Information:</h2>

      <?php
         $TicketID = $DeparturePort = $ArrivalPort = $DepartureTime = $ArrivalTime = $DepartureDate = $ArrivalDate ="";
      ?>

      <label>DeparturePort:</label>
        <input class="input" name="DeparturePort" type="text" value="">
        <br><br>

      <label>ArrivalPort:</label>
        <input class="input" name="ArrivalPort" type="text" value="">
        <br><br>

      <label>DepartureTime:</label>
        <input class="input" name="DepartureTime" type="text" value="">
        <br><br>

      <label>ArrivalTime:</label>
        <input class="input" name="ArrivalTime" type="text" value="">
        <br><br>

      <label>DepartureDate:</label>
        <input class="input" name="DepartureDate" type="text" value="">
        <br><br>

      <label>ArrivalDate:</label>
        <input class="input" name="ArrivalDate" type="text" value="">
        <br><br>
      
      <label>TicketID:</label>
        <input class="input" name="TicketID" type="text" value="">
        <br><br>

    <input class="submit" name="submit" type="submit" value="Submit">
    </form>
    </div>
    </div>

  <?php
    $connection = mysqli_connect("localhost", "root", "", "soloprojtest"); // Establishing Connection with Server
    $db = mysqli_select_db($connection, "soloprojtest"); // Selecting Database from Server
    if(isset($_POST['submit']))
      { // Fetching variables of the form which travels in URL
        $TicketID= $_POST['TicketID'];
        $DeparturePort = $_POST['DeparturePort'];
        $ArrivalPort = $_POST['ArrivalPort'];  
        $DepartureTime= $_POST['DepartureTime'];
        $ArrivalTime = $_POST['ArrivalTime'];    
        $DepartureDate= $_POST['DepartureDate'];
        $ArrivalDate = $_POST['ArrivalDate'];  
      }

    //Insert Query of SQL
    $query = mysqli_query($connection, "INSERT INTO Ticket (TicketID, DeparturePort, ArrivalPort,DepartureTime,ArrivalTime,DepartureDate,ArrivalDate) VALUES ('$TicketID', '$DeparturePort', '$ArrivalPort','$DepartureTime',$ArrivalTime','$DepartureDate',$ArrivalDate')");

    mysqli_close($connection); // Closing Connection with Server
  ?>

</body>
</html>