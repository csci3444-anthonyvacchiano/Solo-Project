<?php session_start(); ?>
<!DOCTYPE html>
<html>
<head>
  <title>Users' Events</title>
  <a href = "HubPage.php">Return to HubPage</a>
</head>

<body>
  <div class="maindiv">
    <!--HTML Form -->
     <div class="form_div">
        <div class="title">
          <h2>Insert User to Ticket Info</h2>
        </div>

      <form action="UserToTicketInsert.php" method="post">
      <h2>User to Event Information:</h2>

      <?php
        $TicketID = $UserID = "";
      ?>

      <label>TicketID:</label>
        <input class="input" name="TicketID" type="text" value="">
        <br><br>

      <label>UserID:</label>
        <input class="input" name="UserID" type="text" value="">
        <br><br>

    <input class="submit" name="submit" type="submit" value="Submit">
    </form>
    </div>
    </div>

  <?php
    $connection = mysqli_connect("localhost", "root", "", "soloprojtest"); // Establishing Connection with Server
    $db = mysqli_select_db($connection, "soloprojtest"); // Selecting Database from Server
    if(isset($_POST['submit']))
      { // Fetching variables of the form which travels in URL
        $TicketID = $_POST['TicketID'];
        $UserID = $_POST['UserID']; 
                
      }

    //Insert Query of SQL
    $query = mysqli_query($connection, "INSERT INTO UserToTicket (TicketID, UserID) VALUES ('$TicketID' , '$UserID')");

    mysqli_close($connection); // Closing Connection with Server
  ?>

</body>
</html>