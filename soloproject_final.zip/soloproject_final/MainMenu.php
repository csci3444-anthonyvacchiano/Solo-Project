<?php
    session_start();

    $_SESSION['username'] = "";
    ob_start();
?>
<!DOCTYPE html>
<html>
<head>

<link href = "css/bootstrap.min.css" rel = "stylesheet">
      
      <style>
         h1 {
            text-align:center;
        }
         h4 {
             text-align:center;
         }
         body {
            padding-top: 40px;
            padding-bottom: 40px;
         }
         
         .form-signin {
            max-width: 330px;
            margin: 0 auto;
         }
         
         .form-signin .form-signin-heading,
         .form-signin .checkbox {
            margin-bottom: 10px;
         }
         
         .form-signin .checkbox {
            font-weight: normal;
         }
         
         .form-signin .form-control {
            position: relative;
            height: auto;
            -webkit-box-sizing: border-box;
            -moz-box-sizing: border-box;
            box-sizing: border-box;
            padding: 10px;
            font-size: 16px;
         }
         
         .form-signin .form-control:focus {
            z-index: 2;
         }
         
         .form-signin input[type="email"] {
            margin-bottom: -1px;
            border-bottom-right-radius: 0;
            border-bottom-left-radius: 0;
            border-color:#017572;
         }
         
         .form-signin input[type="password"] {
            margin-bottom: 10px;
            border-top-left-radius: 0;
            border-top-right-radius: 0;
         }
         
         h2{
            text-align: center;
         }
      </style>
</Head>
<body><h1>Welcome to the Travel Planner!</h1>

<h2> Enter Username and Password, press the enter button, and then click continue </h2>
<div class = "container form-signin">

    <?php
        $msg = '';
        
        if (isset($_POST['submit']) && !empty($_POST['username']) && !empty($_POST['password']))
        {
            if ($_POST['username'] == "planner" && $_POST['password'] == 'planner')
            {
                $_SESSION['username'] = "planner";
            }
            else if ($_POST['username'] == 'traveler' && $_POST['password'] == 'traveler')
            {
                $_SESSION['username'] = 'traveler';
            }

            else
            {
                $_SESSION['username'] = 'invalid';
                $msg = "Wrong username or password";
            }
        }
    ?>
    </div>

    <div class = "container">

    <form class = "form-signin" role = "form" method = "post">
    <h4 class = "form-signin-heading"><?php echo $msg; ?> </h4>
    <input type = "text" class = "form-control" name = "username" placeholder = "username = planner" required autofocus></br>
    <input type = "password" class = "form-control" name = "password" placeholder = "password = pwd" required></br>
    <button class = "btn btn-lg btn-primary btn-block" type = "submit" name = "submit">Login</button>
    </form>

    <h4><a href = "HubPage.php" title = "Continue">Continue</a></h4>

    <h4>
    Click here to clean the <a href = "Logout.php" title = "Logout">Session.
    </h4>
    </div>

</body>
</html>