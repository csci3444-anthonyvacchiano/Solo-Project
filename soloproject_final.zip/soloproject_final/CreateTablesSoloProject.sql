CREATE TABLE Time
(TimeID char(10) NOT NULL, TotalTime decimal(4,2), DepartureTime decimal(4,2), ArrivalTime decimal(4,2),DepartureDate timestamp(4),ArrivalDate timestamp(4),
PRIMARY KEY (TimeID));

CREATE TABLE Ticket
(TicketID char(10) NOT NULL, TimeID char(10) NOT NULL,DeparturePort char(200), ArrivalPort char(200), DepartureTime decimal(4,2), ArrivalTime decimal(4,2),DepartureDate timestamp(4),ArrivalDate timestamp(4),
 PRIMARY KEY (TicketID), FOREIGN KEY (TimeID) REFERENCES Time (TimeID));

CREATE TABLE Location
(LocationID char(10) NOT NULL, DeparturePort char(200), ArrivalPort char(200),DepartureLocation char(200), ArrivalLocation char(200),
PRIMARY KEY (LocationID), FOREIGN KEY (TicketID) REFERENCES Ticket (TicketID));

CREATE TABLE Length
(LengthID char(10) NOT NULL, DeparturePort char(200), ArrivalPort char(200),TotalTime decimal(4,2),
TotalPrice decimal(10,2), PRIMARY KEY (LengthID), FOREIGN KEY (LocationID) REFERENCES Location (LocationID) FOREIGN KEY (TimeID) REFERENCES Time (TimeID));

CREATE TABLE Ride
(RideID char(10) NOT NULL, DeparturePort char(200), ArrivalPort char(200), MethodTravel char(200),
PRIMARY KEY (RideID), FOREIGN KEY (LocationID) REFERENCES Location(LocationID));

CREATE TABLE User
(UserID char(10) NOT NULL, Name char(40), Permissions char(10), UserType char(20),
PRIMARY KEY (UserID));

CREATE TABLE RideToTicket
(TicketID char(10) NOT NULL, RideID char(10) NOT NULL, PRIMARY KEY (TicketID, RideID), 
FOREIGN KEY (TicketID) REFERENCES Ticket(TicketID), FOREIGN KEY (RideID) REFERENCES Ride(RideID));

CREATE TABLE UserToTicket
(TicketID char(10) NOT NULL, UserID char(10) NOT NULL, PRIMARY KEY (TicketID, UserID), 
FOREIGN KEY (TicketID) REFERENCES Ticket(TicketID), FOREIGN KEY (UserID) REFERENCES User(UserID));

