<?php
session_start();
$username = $_SESSION['username'];
?>

<?php
    if ($username == 'planner')
    {
        echo "<h2>Planner Hub</h2>";
        echo "</br><h3>Insert Pages</h3>";
        echo "</br><a href='LocationInsert.php'>Insert Departure Location</a>";
        echo "</br><a href='LengthInsert.php'>Insert Length of Ride</a>";
        echo "</br><a href='TimeInsert.php'>Insert Time </a>";
        echo "</br><a href='TicketInsert.php'>Insert Ticket</a>";
        echo "</br><a href='RideInsert.php'>Insert Type of Ride</a>";
        echo "</br><a href='UserInsert.php'>Insert User</a>";
        echo "</br><a href='RideToTicketInsert.php'>Insert Ride to Ticket</a>";
        echo "</br><a href='UserToTicketInsert.php'>Insert User To Ticket</a>";

        echo "</br><h3>Display Pages</h3>";
        echo "</br><a href='LocationView.php'>View Departure Location</a>";
        echo "</br><a href='LengthView.php'>View Length of Ride</a>";
        echo "</br><a href='TimeView.php'>View Time </a>";
        echo "</br><a href='TicketView.php'>View Ticket</a>";
        echo "</br><a href='RideView.php'>View Type of Ride</a>";
        echo "</br><a href='UserView.php'>View User</a>";
        echo "</br><a href='RideToTicketView.php'>View Ride to Ticket</a>";
        echo "</br><a href='UserToTicketView.php'>View User To Ticket</a>";

    }
    else if ($username == 'traveler')
    {
        echo "<h2>Traveler Hub</h2>";
        echo "</br><h3>Display Pages</h3>";
        echo "</br><a href='LocationView.php'>View Departure Location</a>";
        echo "</br><a href='LengthView.php'>View Length of Ride</a>";
        echo "</br><a href='TimeView.php'>View Time </a>";
        echo "</br><a href='TicketView.php'>View Ticket</a>";
        echo "</br><a href='RideView.php'>View Type of Ride</a>";
        echo "</br><a href='UserView.php'>View User</a>";
        echo "</br><a href='RideToTicketView.php'>View Ride to Ticket</a>";
        echo "</br><a href='UserToTicketView.php'>View User To Ticket</a>";
    }
    else
    {
        echo "<a href = 'MainMenu.php'>Return to Main Menu</a>";
    }
?>